package com.saeed.ashik.weatherappproject.Helper;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.saeed.ashik.weatherappproject.ApplicationController;

/**
 * Created by supto on 31/07/16.
 */
public class PreferenceHelper {
    private static final String DEFAULT_CITY_NAME = "defalt_city_name";
    private static final String TEMP_UNIT = "temparature_unit";
    private static final String SPEED_UNIT = "speed_unit";

    SharedPreferences sharedPreferences;

    public PreferenceHelper() {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(ApplicationController.getApplicationControllerContext());
    }

    public String getDefaultCityName(){
        String cityName;
        cityName = sharedPreferences.getString(DEFAULT_CITY_NAME,"dhaka");
        return cityName;
    }

    public void setDefaultCityName(String cityName){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(DEFAULT_CITY_NAME,cityName);
        editor.apply();
    }
    public String getTempUnit(){
        String tempUnit;
        tempUnit = sharedPreferences.getString(TEMP_UNIT,"Celsius");
        return tempUnit;
    }

    public void setTempUnit(String tempUnit){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEMP_UNIT,tempUnit);
        editor.apply();
    }

    public String getSpeedUnit(){
        String speedUnit;
        speedUnit = sharedPreferences.getString(SPEED_UNIT,"Kilometer");
        return speedUnit;
    }

    public void setSpeedUnit(String speedUnit){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SPEED_UNIT,speedUnit);
        editor.apply();
    }
}
