package com.saeed.ashik.weatherappproject;

import android.app.Application;
import android.content.Context;

/**
 * Created by supto on 31/07/16.
 */
public class ApplicationController extends Application {
    private static ApplicationController applicationController;
    @Override
    public void onCreate() {
        super.onCreate();
        applicationController = this;
    }

    public static Context getApplicationControllerContext(){
        return applicationController.getApplicationContext();
    }
}
