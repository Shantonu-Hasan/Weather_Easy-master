package com.saeed.ashik.weatherappproject;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.saeed.ashik.weatherappproject.Helper.Converter;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;
import com.saeed.ashik.weatherappproject.Helper.VolleySingleton;
import com.saeed.ashik.weatherappproject.Model.WeatherNow;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by supto on 31/07/16.
 */
public class FragmentWeatherNow extends Fragment {
    private static String apiURlFirst = "http://api.openweathermap.org/data/2.5/weather?q=";
    private static String apiURlsecond = "&appid=";

    PreferenceHelper preferenceHelper;

    String cityName;
    String tempUnit;
    String speedUnit;

    WeatherNow weatherNow;
    TextView weatherNowTempTV;
    TextView weatherNowHumidityTV;
    TextView weatherNowWindSpeedTV;
    TextView weatherNowDescriptionTV;
    ImageView weatherNowWindDirectionImage;
    ImageView weatherNowMainImage;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_weather_now, container, false);

        preferenceHelper = new PreferenceHelper();
        cityName = preferenceHelper.getDefaultCityName();
        tempUnit = preferenceHelper.getTempUnit();
        speedUnit = preferenceHelper.getSpeedUnit();


        weatherNowTempTV = (TextView) view.findViewById(R.id.weatherNowTempTV);
        weatherNowHumidityTV = (TextView) view.findViewById(R.id.weatherNowHumidityTV);
        weatherNowWindSpeedTV = (TextView) view.findViewById(R.id.weatherNowWindSpeedTV);
        weatherNowWindDirectionImage = (ImageView) view.findViewById(R.id.weatherNowWindDirectionImage);
        weatherNowMainImage = (ImageView) view.findViewById(R.id.weatherNowMainImage);
        weatherNowDescriptionTV = (TextView) view.findViewById(R.id.weatherNowDescriptionTV);

        String api_url = apiURlFirst + cityName + apiURlsecond + getResources().getString(R.string.api_key);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                weatherNow = getWeatherNowModelFromResponse(response);
                updateUi();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
        VolleySingleton.getInstance().addToRequestQueue(stringRequest);

        return view;
    }


    private void updateUi() {
        weatherNowDescriptionTV.setText(weatherNow.getDescription());

        switch (weatherNow.getMain()){
            case ("Clear"):
                weatherNowMainImage.setImageResource(R.drawable.sunny);
                break;
            case ("Clouds"):
                weatherNowMainImage.setImageResource(R.drawable.partially_cloudy);
                break;
            case ("Rain"):
                weatherNowMainImage.setImageResource(R.drawable.rainy);
                break;
            case ("storm"):
                weatherNowMainImage.setImageResource(R.drawable.thunderstorm);
                break;
            default:
                weatherNowMainImage.setImageResource(R.drawable.sunny);
                break;
        }

        if (tempUnit.contentEquals("Celsius")) {
            weatherNowTempTV.setText(Converter.getCelsiusFromKelvin(weatherNow.getCurrentTemp()) + "\u00b0C");

        } else if (tempUnit.contentEquals("Fahrenheit")) {
            weatherNowTempTV.setText(Converter.getFahrenheitFromKelvin(weatherNow.getCurrentTemp()) + "\u00b0F");

        }

        if (speedUnit.contentEquals("Mile")) {
            weatherNowWindSpeedTV.setText("Wind speed \n"+Converter.getMphFromMps(weatherNow.getWindSpeed()) + " mph");

        } else if (speedUnit.contentEquals("Kilometer")) {
            weatherNowWindSpeedTV.setText("Wind speed \n"+Converter.getKmphFromMps(weatherNow.getWindSpeed()) + " kmph");

        }

        weatherNowWindDirectionImage.setRotation(weatherNow.getWindDirection().floatValue());
        weatherNowHumidityTV.setText("Humidity\n" + Converter.numberFormater(weatherNow.getHumidity(), "#") + " %");
    }


    private WeatherNow getWeatherNowModelFromResponse(String response) {
        WeatherNow weatherNow;

        try {
            JSONObject parentObject = new JSONObject(response);

            String main = parentObject.getJSONArray("weather").getJSONObject(0).getString("main");
            String description = parentObject.getJSONArray("weather").getJSONObject(0).getString("description");
            Double currentTemp = parentObject.getJSONObject("main").getDouble("temp");
            Double windSpeed = parentObject.getJSONObject("wind").getDouble("speed");
            Double windDirection = parentObject.getJSONObject("wind").getDouble("deg");
            Double humidity = parentObject.getJSONObject("main").getDouble("humidity");

            weatherNow = new WeatherNow(main, description, currentTemp, windSpeed, windDirection, humidity);
            return weatherNow;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
