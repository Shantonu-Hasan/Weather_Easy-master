package com.saeed.ashik.weatherappproject.Helper;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by supto on 02/08/16.
 */
public class Converter {

    public static String getCelsiusFromKelvin(double kelvin) {
        double celsius = kelvin - 273.15d;
        DecimalFormat decimalFormat = new DecimalFormat("#");
        return decimalFormat.format(celsius);
    }

    public static String getFahrenheitFromKelvin(double kelvin) {
        double fahrenheit = (kelvin - 273.15) * 1.8000 + 32.00;
        DecimalFormat decimalFormat = new DecimalFormat("#");
        return decimalFormat.format(fahrenheit);
    }

    public static String getKmphFromMps(double mps) {
        double kmph = mps * 3.6;
        DecimalFormat decimalFormat = new DecimalFormat("#");
        return decimalFormat.format(kmph);
    }

    public static String getMphFromMps(double mps) {
        double mph = mps * 2.237;
        DecimalFormat decimalFormat = new DecimalFormat("#");
        return decimalFormat.format(mph);
    }

    public static String getDateFromUnixTimeForHourly(long time){
        Date date = new Date(time*1000L); // *1000 is to convert seconds to milliseconds
        Calendar  calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY,6);
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE \n dd MMM yyyy \n hh:mm a"); // the format of your date
        String formattedDate = sdf.format(calendar.getTime());
        return formattedDate;
    }
    public static String getDateFromUnixTimeForDaily(long time){
        Date date = new Date(time*1000L); // *1000 is to convert seconds to milliseconds
        Calendar  calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY,6);
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE \n dd MMM yyyy"); // the format of your date
        String formattedDate = sdf.format(calendar.getTime());
        return formattedDate;
    }

    public static String numberFormater(Object input, String formatType) {
        DecimalFormat decimalFormat = new DecimalFormat(formatType);
        return decimalFormat.format(input);
    }

}
