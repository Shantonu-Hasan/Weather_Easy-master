package com.saeed.ashik.weatherappproject.Model;

/**
 * Created by supto on 03/08/16.
 */
public class WeatherDaily {
    private String main;
    private Double minTemp;
    private Double maxTemp;
    private Double humidity;
    private long date;

    public WeatherDaily(String main, Double minTemp, Double maxTemp, Double humidity, long date) {

        this.main = main;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.humidity = humidity;
        this.date = date;
    }

    public String getMain() {
        return main;
    }

    public Double getMinTemp() {
        return minTemp;
    }

    public Double getMaxTemp() {
        return maxTemp;
    }

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public long getDate() {
        return date;
    }

}
