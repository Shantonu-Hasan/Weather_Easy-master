package com.saeed.ashik.weatherappproject.Model;

/**
 * Created by supto on 31/07/16.
 */
public class WeatherNow {
    private String main;
    private String description;
    private Double currentTemp;
    private Double windSpeed;
    private Double windDirection;
    private Double humidity;

    public WeatherNow(String main, String description, Double currentTemp, Double windSpeed, Double windDirection, Double humidity) {
        this.main = main;
        this.description = description;
        this.currentTemp = currentTemp;
        this.windSpeed = windSpeed;
        this.windDirection = windDirection;
        this.humidity = humidity;

    }

    public String getMain() {
        return main;
    }

    public String getDescription() {
        return description;
    }

    public Double getCurrentTemp() {
        return currentTemp;
    }

    public Double getWindSpeed() {
        return windSpeed;
    }

    public Double getWindDirection() {
        return windDirection;
    }

    public Double getHumidity() {
        return humidity;
    }


}
