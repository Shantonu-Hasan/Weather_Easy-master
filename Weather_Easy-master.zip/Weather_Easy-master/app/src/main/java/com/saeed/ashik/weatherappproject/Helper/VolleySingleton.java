package com.saeed.ashik.weatherappproject.Helper;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.saeed.ashik.weatherappproject.ApplicationController;

/**
 * Created by supto on 31/07/16.
 */
public class VolleySingleton {
    private static VolleySingleton mySingletonInstance = null;
    private RequestQueue requestQueue;

    private VolleySingleton(){
        requestQueue = Volley.newRequestQueue(ApplicationController.getApplicationControllerContext());
    }

    public static VolleySingleton getInstance(){
        if(mySingletonInstance == null){
            mySingletonInstance = new VolleySingleton();
        }
        return mySingletonInstance;
    }

    public RequestQueue getRequestQueue() {
        return requestQueue;
    }

    // custom methods for volley
    public void addToRequestQueue(Request request){
        RequestQueue requestQueue = VolleySingleton.getInstance().getRequestQueue();
        requestQueue.add(request);
    }
}
