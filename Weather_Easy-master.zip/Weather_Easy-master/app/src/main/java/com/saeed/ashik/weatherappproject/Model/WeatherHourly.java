package com.saeed.ashik.weatherappproject.Model;

/**
 * Created by supto on 04/08/16.
 */
public class WeatherHourly {
    private String main;
    private Double temp;
    private Double humidity;
    private long date;


    public WeatherHourly(String main, Double temp, Double humidity, long date) {
        this.main = main;
        this.temp = temp;

        this.humidity = humidity;
        this.date = date;
    }

    public String getMain() {
        return main;
    }

    public Double getTemp() {
        return temp;
    }

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public long getDate() {
        return date;
    }


}
