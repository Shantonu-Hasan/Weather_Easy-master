package com.saeed.ashik.weatherappproject;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.saeed.ashik.weatherappproject.Adapter.WeatherHourlyListAdapter;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;
import com.saeed.ashik.weatherappproject.Helper.VolleySingleton;
import com.saeed.ashik.weatherappproject.Model.WeatherHourly;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by supto on 02/08/16.
 */
public class FragmentForecastHourly extends Fragment {

    private static String apiFirst = "http://api.openweathermap.org/data/2.5/forecast?q=";
    private static String apisecond = "&appid=";

    PreferenceHelper preferenceHelper;
    String cityName;
    String tempUnit;
    String speedUnit;
    ListView listView;
    WeatherHourlyListAdapter listAdapter;
    ArrayList<WeatherHourly> weatherHourlise;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forecast_hourly, container, false);

        preferenceHelper = new PreferenceHelper();
        cityName = preferenceHelper.getDefaultCityName();
        tempUnit = preferenceHelper.getTempUnit();
        speedUnit = preferenceHelper.getSpeedUnit();
        listView = (ListView) view.findViewById(R.id.weatherHourlyList);
        weatherHourlise = new ArrayList<>();

        String api_url = apiFirst + cityName + apisecond + getResources().getString(R.string.api_key);
        StringRequest stringRequest2 = new StringRequest(Request.Method.GET, api_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                weatherHourlise = getWeatherHourlies(response);
                listAdapter = new WeatherHourlyListAdapter(getActivity(), R.layout.list_item_daily, weatherHourlise);
                listView.setAdapter(listAdapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
            }
        });

        VolleySingleton.getInstance().addToRequestQueue(stringRequest2);
        return view;
    }

    private ArrayList<WeatherHourly> getWeatherHourlies(String response) {
        ArrayList<WeatherHourly> weatherHourlies = new ArrayList<>();
        try {
            JSONObject parentObject = new JSONObject(response);

            for (int i = 0; i < parentObject.getJSONArray("list").length(); i++) {
                String main = parentObject.getJSONArray("list").getJSONObject(i).getJSONArray("weather").getJSONObject(0).getString("main");
                Double temp = parentObject.getJSONArray("list").getJSONObject(i).getJSONObject("main").getDouble("temp");
                Double humidity = parentObject.getJSONArray("list").getJSONObject(i).getJSONObject("main").getDouble("humidity");
                long date = parentObject.getJSONArray("list").getJSONObject(i).getLong("dt");
                WeatherHourly weatherHourly = new WeatherHourly(main, temp, humidity, date);
                weatherHourlies.add(weatherHourly);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return weatherHourlies;
    }
}