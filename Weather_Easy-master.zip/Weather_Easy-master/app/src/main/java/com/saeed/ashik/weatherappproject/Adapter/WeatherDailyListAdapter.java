package com.saeed.ashik.weatherappproject.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.saeed.ashik.weatherappproject.Helper.Converter;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;
import com.saeed.ashik.weatherappproject.Model.WeatherDaily;
import com.saeed.ashik.weatherappproject.R;

import java.util.ArrayList;

/**
 * Created by supto on 03/08/16.
 */
public class WeatherDailyListAdapter extends ArrayAdapter<WeatherDaily> {
    private Context context;
    private int resource;
    private ArrayList<WeatherDaily> weatherDailies;

    PreferenceHelper preferenceHelper;
    String cityName;
    String tempUnit;
    String speedUnit;

    public WeatherDailyListAdapter(Context context, int resource, ArrayList<WeatherDaily> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        weatherDailies = objects;

        preferenceHelper = new PreferenceHelper();
        cityName = preferenceHelper.getDefaultCityName();
        tempUnit = preferenceHelper.getTempUnit();
        speedUnit = preferenceHelper.getSpeedUnit();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        ViewHolder viewHolder;
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(resource, parent, false);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        WeatherDaily weatherDaily = weatherDailies.get(position);

        //set date textview
        viewHolder.dateTv.setText(Converter.getDateFromUnixTimeForDaily(weatherDaily.getDate()));

        //set main image
        switch (weatherDaily.getMain()) {
            case ("Clear"):
                viewHolder.mainImageView.setImageResource(R.drawable.sunny);
                break;
            case ("Clouds"):
                viewHolder.mainImageView.setImageResource(R.drawable.partially_cloudy);
                break;
            case ("Rain"):
                viewHolder.mainImageView.setImageResource(R.drawable.rainy);
                break;
            case ("storm"):
                viewHolder.mainImageView.setImageResource(R.drawable.thunderstorm);
                break;
            default:
                viewHolder.mainImageView.setImageResource(R.drawable.sunny);
                break;
        }

        //format and set min & max temp
        if (tempUnit.contentEquals("Celsius")) {
            viewHolder.tempTv.setText(Converter.getCelsiusFromKelvin(weatherDaily.getMinTemp()) + "\u00b0C / " + Converter.getCelsiusFromKelvin(weatherDaily.getMaxTemp()) + "°C");
        } else if (tempUnit.contentEquals("Fahrenheit")) {
            viewHolder.tempTv.setText(Converter.getFahrenheitFromKelvin(weatherDaily.getMinTemp()) + "\u00b0F / " + Converter.getFahrenheitFromKelvin(weatherDaily.getMaxTemp()) + "°F");
        }

        //set humidity
        if (weatherDaily.getHumidity() != 0) {
            viewHolder.humidityTV.setText(Converter.numberFormater(weatherDaily.getHumidity(), "#") + " %");
        } else {
            viewHolder.humidityTV.setText("Not available");
        }

        //set different list item colour
        if (position % 4 == 0) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.background_major));
        } else if (position % 4 == 1) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.background_one));
        } else if (position % 4 == 2) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.background_two));
        } else if (position % 4 == 3) {
            view.setBackgroundColor(getContext().getResources().getColor(R.color.background_three));
        }
        return view;
    }

    private static class ViewHolder {
        private TextView dateTv;
        private TextView tempTv;
        private TextView humidityTV;
        ImageView mainImageView;

        public ViewHolder(View view) {
            dateTv = (TextView) view.findViewById(R.id.weatherDaliyListDateTv);
            tempTv = (TextView) view.findViewById(R.id.weatherDailyListTempTv);
            humidityTV = (TextView) view.findViewById(R.id.weatherDailyListHumidityTV);
            mainImageView = (ImageView) view.findViewById(R.id.weatherDailyListMainImageView);
        }
    }
}
