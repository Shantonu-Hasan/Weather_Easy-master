package com.saeed.ashik.weatherappproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.saeed.ashik.weatherappproject.Adapter.ViewPagerAdapter;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView weatherNowTV;
    TextView forecastDailyTV;
    TextView forecastHourlyTV;
    ViewPager viewPager;
    ViewPagerAdapter viewPagerAdapter;
    String cityName;
    Toast exitToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weatherNowTV = (TextView) findViewById(R.id.weatehrNowTV);
        forecastDailyTV = (TextView) findViewById(R.id.forecastDailyTV);
        forecastHourlyTV = (TextView) findViewById(R.id.forecastHourlyTV);

        exitToast = Toast.makeText(MainActivity.this, "Press back again to exit", Toast.LENGTH_SHORT);

        weatherNowTV.setTypeface(null, Typeface.BOLD);
        forecastDailyTV.setTypeface(null, Typeface.NORMAL);
        forecastHourlyTV.setTypeface(null, Typeface.NORMAL);

        weatherNowTV.setOnClickListener(this);
        forecastDailyTV.setOnClickListener(this);
        forecastHourlyTV.setOnClickListener(this);

        viewPager = (ViewPager) findViewById(R.id.viewPager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    weatherNowTV.setTypeface(null, Typeface.BOLD);
                    forecastDailyTV.setTypeface(null, Typeface.NORMAL);
                    forecastHourlyTV.setTypeface(null, Typeface.NORMAL);
                } else if (position == 1) {
                    weatherNowTV.setTypeface(null, Typeface.NORMAL);
                    forecastDailyTV.setTypeface(null, Typeface.NORMAL);
                    forecastHourlyTV.setTypeface(null, Typeface.BOLD);

                } else if (position == 2) {
                    weatherNowTV.setTypeface(null, Typeface.NORMAL);
                    forecastDailyTV.setTypeface(null, Typeface.BOLD);
                    forecastHourlyTV.setTypeface(null, Typeface.NORMAL);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });


    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        //get the city name, make the first letter capital and display as title
        cityName = new PreferenceHelper().getDefaultCityName();
        cityName = cityName.substring(0, 1).toUpperCase() + cityName.substring(1);
        getSupportActionBar().setTitle(cityName);

        // to set the actionbar title text color
        Spannable text = new SpannableString(getSupportActionBar().getTitle());
        text.setSpan(new ForegroundColorSpan(Color.WHITE), 0, text.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        getSupportActionBar().setTitle(text);


        //initiate the view pager
        viewPager.setAdapter(viewPagerAdapter);
    }

    @Override
    public void onBackPressed() {

        // to show the exit toast
        if (exitToast.getView().isShown()) {
            super.onBackPressed();
        } else {
            exitToast.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.settingMenuButton) {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
        }
        return true;
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.weatehrNowTV) {
            viewPager.setCurrentItem(0, true);
        } else if (id == R.id.forecastHourlyTV) {
            viewPager.setCurrentItem(1, true);
        } else if (id == R.id.forecastDailyTV) {
            viewPager.setCurrentItem(2, true);
        }
    }
}
