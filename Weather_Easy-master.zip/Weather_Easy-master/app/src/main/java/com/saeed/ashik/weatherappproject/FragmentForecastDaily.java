package com.saeed.ashik.weatherappproject;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.saeed.ashik.weatherappproject.Adapter.WeatherDailyListAdapter;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;
import com.saeed.ashik.weatherappproject.Helper.VolleySingleton;
import com.saeed.ashik.weatherappproject.Model.WeatherDaily;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by supto on 31/07/16.
 */
public class FragmentForecastDaily extends Fragment {
    private static String apiURlFirst = "http://api.openweathermap.org/data/2.5/forecast/daily?q=";
    private static String apiURlsecond = "&appid=";
    private static String apiURlThird = "&cnt=16";

    PreferenceHelper preferenceHelper;
    String cityName;
    String tempUnit;
    String speedUnit;
    ListView listView;
    WeatherDailyListAdapter listAdapter;
    ArrayList<WeatherDaily> weatherDailies;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forecast_daily, container, false);

        preferenceHelper = new PreferenceHelper();
        cityName = preferenceHelper.getDefaultCityName();
        tempUnit = preferenceHelper.getTempUnit();
        speedUnit = preferenceHelper.getSpeedUnit();
        listView = (ListView) view.findViewById(R.id.weatherDailyList);
        weatherDailies = new ArrayList<>();


        String api_url = apiURlFirst + cityName + apiURlsecond + getResources().getString(R.string.api_key)+apiURlThird;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                weatherDailies = getWeatherDailies(response);
                listAdapter= new WeatherDailyListAdapter(getActivity(),R.layout.list_item_daily,weatherDailies);
                listView.setAdapter(listAdapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
            }
        });

        VolleySingleton.getInstance().addToRequestQueue(stringRequest);
        return view;
    }

    private ArrayList<WeatherDaily> getWeatherDailies(String response) {
        ArrayList<WeatherDaily> weatherDailies = new ArrayList<>();
        try {

            JSONObject parentObject = new JSONObject(response);
            for (int i = 0; i < parentObject.getJSONArray("list").length(); i++) {
                String main = parentObject.getJSONArray("list").getJSONObject(i).getJSONArray("weather").getJSONObject(0).getString("main");
                Double minTemp = parentObject.getJSONArray("list").getJSONObject(i).getJSONObject("temp").getDouble("min");
                Double maxTemp = parentObject.getJSONArray("list").getJSONObject(i).getJSONObject("temp").getDouble("max");
                Double humidity = parentObject.getJSONArray("list").getJSONObject(i).getDouble("humidity");
                long date = parentObject.getJSONArray("list").getJSONObject(i).getLong("dt");
                WeatherDaily weatherDaily = new WeatherDaily(main, minTemp, maxTemp, humidity, date);
                weatherDailies.add(weatherDaily);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return weatherDailies;
    }

}
