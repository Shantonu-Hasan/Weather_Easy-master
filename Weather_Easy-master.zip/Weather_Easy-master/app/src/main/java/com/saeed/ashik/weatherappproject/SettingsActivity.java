package com.saeed.ashik.weatherappproject;

import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.saeed.ashik.weatherappproject.Helper.PreferenceHelper;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    EditText setCityET;
    Button save;
    RadioGroup tempRG;
    RadioGroup speedRG;
    RadioButton span;
    Button getLocationButton;

    PreferenceHelper preferenceHelper;
    GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        preferenceHelper = new PreferenceHelper();
        setCityET = (EditText) findViewById(R.id.setCityET);
        tempRG = (RadioGroup) findViewById(R.id.tempRG);
        speedRG = (RadioGroup) findViewById(R.id.speedRG);
        save = (Button) findViewById(R.id.saveSettings);
        getLocationButton = (Button) findViewById(R.id.getLocationButton);

        save.setOnClickListener(this);
        getLocationButton.setOnClickListener(this);


        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        String defaultCity = preferenceHelper.getDefaultCityName();
        setCityET.setText(defaultCity);

        String tempUnit = preferenceHelper.getTempUnit();
        if (tempUnit.contentEquals("Celsius")) {
            tempRG.check(R.id.celsiusRB);
        } else if (tempUnit.contentEquals("Fahrenheit")) {
            tempRG.check(R.id.fahrenheitRB);
        }

        String speedUnit = preferenceHelper.getSpeedUnit();
        if (speedUnit.contentEquals("Kilometer")) {
            speedRG.check(R.id.kilometerRB);
        } else if (speedUnit.contentEquals("Mile")) {
            speedRG.check(R.id.mileRB);
        }
        mGoogleApiClient.connect();
    }

    @Override
    protected void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }

    @Override
    public void onConnected(Bundle connectionHint) {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();


        if (id == R.id.saveSettings) {
            // saved default city
            String cityName = setCityET.getText().toString();
            if (!cityName.contentEquals("null") && !cityName.contentEquals("")) {
                preferenceHelper.setDefaultCityName(cityName);
            }

            //set temp unit
            span = (RadioButton) findViewById(tempRG.getCheckedRadioButtonId());
            String tempUnit = span.getText().toString();
            preferenceHelper.setTempUnit(tempUnit);

            //set speed unit
            span = (RadioButton) findViewById(speedRG.getCheckedRadioButtonId());
            String speedUnit = span.getText().toString();
            preferenceHelper.setSpeedUnit(speedUnit);
            finish();


        } else if (id == R.id.getLocationButton) {

            // if mLastLocation is not null then set the cityname in setCity Edittext
            if (mLastLocation != null) {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = null;
                try {
                    addresses = geocoder.getFromLocation(mLastLocation.getLatitude(), mLastLocation.getLongitude(), 1);
                    String cityName = addresses.get(0).getAddressLine(1);
                    setCityET.setText(cityName);
                    Toast.makeText(SettingsActivity.this, "You are now at " + cityName, Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
    }


}
